RG MENABUNG — Panduan
========================

ISI ZIP INI (RGxMenabung.zip)
--------------------------------
index.html   -> semua layar (Auth, Home, Buat Tabungan, Detail, Owner
                Panel, Ganti Password) dalam 1 file, berpindah pakai
                JavaScript dengan animasi smooth (bukan reload halaman)
css/style.css -> styling (tema blue/cyan) + semua animasi transisi
js/app.js    -> semua logika: auth, simpan/ambil data, progress, history,
                format angka, notifikasi
README.txt   -> file ini
assets/video/ -> taruh 1 file video di sini (lihat bawah)

CATATAN: file .github/workflows/build.yml TIDAK ada di dalam zip ini —
itu harus diupload terpisah langsung ke GitHub (bukan lewat zip), lihat
bagian "PURE HP, TANPA KOMPUTER" di bawah.

FILE ASET YANG WAJIB DITAMBAHKAN (nama harus persis)
------------------------------------------------------
assets/video/Backround1.mp4 -> video background di belakang seluruh
                                  layar app, auto-loop, tanpa suara.
                                  Rekomendasi rasio 9:16 (mengikuti bentuk
                                  frame app), video pendek (3-8 detik)
                                  biar ringan dan loop-nya mulus.

Kalau file belum ada, background akan tetap gelap polos — bukan error.

CARA COBA
---------
Buka index.html langsung di browser (double click), atau jalankan lewat
local server (lebih stabil untuk upload gambar besar):
    python3 -m http.server 8080
lalu buka http://localhost:8080/

CARA KERJA DATA
----------------
Semua tabungan disimpan di localStorage HP/browser (tersimpan otomatis,
tidak perlu internet, tidak terkirim ke server manapun). Struktur per
tabungan: nama, gambar (base64), target, menabung per hari, jadwal
(hari+jam), tanggal dibuat, perkiraan tanggal selesai, currentTotal
(total terkumpul), dan history (tanggal, hari, waktu, jumlah, alasan
tiap kali "Tambah Tabungan" ditekan).

LOGIN / DAFTAR AKUN
-----------------------
- Tiap akun punya data tabungan sendiri-sendiri, TERPISAH dari akun
  lain (key localStorage beda per username: piggy_banks_<username>).
- Password disimpan sebagai HASH (SHA-256 + salt random per akun),
  bukan teks polos — dihitung pakai Web Crypto API bawaan browser,
  tidak butuh library dari luar.
- CATATAN JUJUR soal keamanan: karena app ini tanpa server/backend,
  ini bukan setara keamanan aplikasi login sungguhan. Siapa pun yang
  akses langsung ke storage device (misalnya lewat HP yang di-root)
  tetap bisa melihat data mentahnya. Untuk keamanan production
  sungguhan, ini perlu backend asli dengan autentikasi server-side.

AKUN OWNER (BAWAAN)
-----------------------
Akun berikut otomatis dibuat saat app pertama kali dibuka di suatu
perangkat:
    Username: KyroRG
    Password: SUPER SUS

Akun ini punya tombol tambahan (ikon mata) di halaman Home yang buka
"Owner Panel", isinya:
- Statistik gabungan: total user terdaftar, total tabungan dibuat,
  total uang terkumpul semua akun, rata-rata per user
- Daftar USERNAME semua akun terdaftar

Owner Panel SENGAJA TIDAK menampilkan password (walau dalam bentuk
hash) maupun data tabungan pribadi (nama, foto, alasan, history) milik
akun tertentu. Password di-hash satu arah (SHA-256) sehingga secara
teknis memang tidak bisa "ditampilkan kembali" — dan walau bisa,
memberi satu akun akses lihat password semua orang justru menambah
risiko keamanan, bukan menguranginya (kalau akun itu bocor, semua
akun lain ikut kebobol). Solusi untuk akun yang dicurigai bocor ada di
fitur Ganti Password di bawah.

Kalau login sebagai KyroRG di HP lain, Owner Panel-nya cuma akan
menghitung akun-akun yang terdaftar DI HP ITU JUGA (karena data
memang tidak tersimpan di server bersama, cuma lokal per perangkat).

GANTI PASSWORD
------------------
Tombol ikon kunci (🔑) di Home membuka halaman Ganti Password. User
mana pun (termasuk owner) bisa ganti password akunnya sendiri kapan
saja — perlu masukkan password lama dulu (diverifikasi lewat hash)
sebelum bisa set password baru. Ini cara yang tepat kalau curiga
akun sendiri bocor: langsung ganti password, bukan minta orang lain
(termasuk owner) bisa lihat password siapa pun.

FORMAT ANGKA & TANGGAL
-------------------------
- Target Tabungan, Menabung Perhari, dan Uang otomatis diberi titik
  ribuan saat diketik (1000 -> 1.000), tersimpan sebagai angka biasa
  di balik layar.
- "Tabungan dibuat" = tanggal saat tombol Mulai Menabung ditekan.
- "Tabungan selesai" = PERKIRAAN, dihitung otomatis dari target, jumlah
  menabung per hari, dan hari yang dipilih (bukan tanggal pasti, karena
  tergantung kamu benar-benar menabung sesuai jadwal atau tidak).

TENTANG NOTIFIKASI (SUNGGUHAN)
----------------------------------
Ada 2 jalur notifikasi di kode ini, otomatis dipilih sesuai environment:

1. BROWSER BIASA (untuk coba-coba sekarang)
   Pakai Web Notification API bawaan browser. JUJUR SOAL BATASANNYA:
   ini HANYA bisa muncul selama tab/app ini masih terbuka (boleh di
   background/minimized, tapi tidak boleh benar-benar ditutup), karena
   browser tidak bisa "membangunkan diri sendiri" seperti alarm sistem.
   Browser akan minta izin notifikasi saat pertama kali dibuka — izinkan
   supaya fitur ini aktif.

2. APK — NOTIFIKASI ASLI, JALAN WALAU APP DITUTUP TOTAL
   Ini yang benar-benar "notifikasi sungguhan" seperti alarm HP biasa.
   Butuh plugin Capacitor Local Notifications:

   1. npm install @capacitor/local-notifications
   2. npx cap sync android
   3. Build ulang APK.

   Setelah plugin ini aktif, tiap kali tabungan baru dibuat dengan jam
   yang diisi, notifikasi otomatis dijadwalkan untuk berulang tiap
   minggu di hari+jam yang dipilih — sistem Android sendiri yang
   membangunkan notifikasinya, bukan JavaScript, jadi tetap muncul
   walau app sudah ditutup dari recent apps.

CARA MENGUBAH INI MENJADI FILE .APK
-------------------------------------
Ada 2 jalur:

A) PAKAI KOMPUTER (Node.js + Android Studio) — lihat panduan Capacitor
   standar (npm install @capacitor/core @capacitor/cli, npx cap init,
   npx cap add android, dst).

B) PURE HP, TANPA KOMPUTER — pakai GitHub Actions, upload ZIP APA ADANYA
   (TANPA DI-EXTRACT). File workflow-nya sudah disiapkan terpisah (lihat
   di bawah), karena GitHub cuma bisa baca workflow dari path
   .github/workflows/*.yml sebagai file asli di repo — bukan dari isi
   dalam zip. Makanya prosesnya 2 upload terpisah:

   1. Upload file INI (RGxMenabung.zip) APA ADANYA ke root repository
      lewat GitHub: Add file > Upload files > pilih RGxMenabung.zip >
      Commit. JANGAN di-extract dulu di HP, upload persis file .zip-nya.

   2. Upload file workflow secara terpisah: Add file > Create new file >
      nama file (ketik persis, biar otomatis ke-nest ke foldernya):
        .github/workflows/build.yml
      Isinya sudah disiapkan terpisah (diberikan lengkap di percakapan
      dengan Claude) — tinggal copy-paste ke kotak besar GitHub, lalu
      Commit changes.

   3. Push ke commit ke-2 otomatis memicu GitHub Actions. Buka tab
      "Actions" di repo, tunggu sampai centang hijau. Workflow-nya akan
      otomatis: unzip RGxMenabung.zip di server GitHub -> siapkan
      folder www -> install Capacitor + semua plugin -> build APK.

   4. Buka run yang selesai -> bagian "Artifacts" -> download
      "rg-menabung-apk" -> install ke HP (aktifkan dulu "Izinkan instal
      dari sumber tidak dikenal").

   Setiap kali kode diubah: bikin ulang RGxMenabung.zip -> upload timpa
   yang lama (klik file lama di repo > ikon pensil/Edit > atau hapus lalu
   upload baru) -> build APK baru otomatis jalan lagi.

   CATATAN: file APK dari cara ini adalah versi DEBUG (untuk dites di HP
   sendiri), belum untuk dipublish ke Play Store — itu proses signing
   terpisah, beda topik lagi kalau nanti sampai situ.
