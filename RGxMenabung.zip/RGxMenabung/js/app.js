/* =========================================================
   CELENGAN — app.js

   AUTH: akun disimpan di localStorage key "piggy_accounts"
   (array of { username, salt, hash, isOwner, createdAt }).
   Password di-hash SHA-256 + salt, bukan teks polos.

   DATA TABUNGAN: per-akun, key "piggy_banks_<username>", isinya
   array of:
   {
     id, name, image (dataURL), target, dailyAmount,
     days: [...], time, createdAt, estimatedCompletion,
     currentTotal, history: [{ id, timestamp, amount, reason }]
   }

   OWNER: akun "KyroRG" dibuat otomatis saat pertama kali app
   dibuka (lihat ensureOwnerSeed). Owner cuma bisa lihat statistik
   GABUNGAN semua akun (total user, total tabungan, total uang) —
   TIDAK bisa lihat nama tabungan/history/alasan milik akun lain.
   ========================================================= */

(function () {
  "use strict";

  const STORAGE_KEY_PREFIX = "piggy_banks_";
  const ACCOUNTS_KEY = "piggy_accounts";
  const SESSION_KEY = "piggy_session";
  const DAY_NAMES = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
  const MONTH_NAMES = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
  // Capacitor LocalNotifications pakai weekday 1=Minggu ... 7=Sabtu
  const CAP_WEEKDAY = { Minggu: 1, Senin: 2, Selasa: 3, Rabu: 4, Kamis: 5, Jumat: 6, Sabtu: 7 };

  function currentStorageKey() {
    return STORAGE_KEY_PREFIX + (getSession() || "guest");
  }

  function loadGoals() {
    try {
      const raw = localStorage.getItem(currentStorageKey());
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  function saveGoals(goals) {
    localStorage.setItem(currentStorageKey(), JSON.stringify(goals));
  }

  function formatRupiah(n) {
    const num = Number(n) || 0;
    return "Rp" + num.toLocaleString("id-ID");
  }

  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  function formatDateLong(timestamp) {
    if (!timestamp) return "-";
    const d = new Date(timestamp);
    return d.getDate() + ", " + MONTH_NAMES[d.getMonth()] + ", " + d.getFullYear();
  }

  // Hitung perkiraan tanggal tabungan selesai: jalan hari demi hari dari
  // tanggal dibuat, hanya menambah "menabung perhari" pada hari yang
  // dipilih (kalau tidak pilih hari sama sekali, dianggap tiap hari),
  // sampai totalnya mencapai target.
  function computeEstimatedCompletion(createdAt, target, dailyAmount, days) {
    if (!dailyAmount || dailyAmount <= 0 || !target || target <= 0) return null;
    const activeDays = days && days.length ? days : DAY_NAMES.slice();
    const cursor = new Date(createdAt);
    cursor.setHours(0, 0, 0, 0);
    let total = 0;
    for (let i = 0; i < 3660; i++) {
      const dayName = DAY_NAMES[cursor.getDay()];
      if (activeDays.includes(dayName)) {
        total += dailyAmount;
        if (total >= target) return cursor.getTime();
      }
      cursor.setDate(cursor.getDate() + 1);
    }
    return null; // lebih dari ~10 tahun, tidak dihitung
  }

  // Format input angka jadi bertitik ribuan saat mengetik (mis. 1000 -> 1.000)
  function attachThousandFormatting(el) {
    el.addEventListener("input", () => {
      const digits = el.value.replace(/\D/g, "");
      el.value = digits ? Number(digits).toLocaleString("id-ID") : "";
    });
  }

  function parseFormattedNumber(el) {
    return Number(el.value.replace(/\D/g, "")) || 0;
  }

  // ---------- AUTH: AKUN, HASH PASSWORD, SESSION ----------
  // Password di-hash pakai SHA-256 (Web Crypto API bawaan browser/WebView,
  // tidak butuh library luar) + salt random per akun. CATATAN JUJUR:
  // karena ini app tanpa server (semua data di localStorage HP), ini
  // bukan tingkat keamanan setara backend sungguhan — siapa pun yang
  // akses langsung ke storage device tetap bisa lihat data mentahnya.
  // Tujuannya di sini supaya password minimal tidak tersimpan polos.
  async function sha256Hex(text) {
    const enc = new TextEncoder().encode(text);
    const buf = await crypto.subtle.digest("SHA-256", enc);
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
  }

  function randomSalt() {
    return Math.random().toString(36).slice(2) + Date.now().toString(36);
  }

  function loadAccounts() {
    try {
      const raw = localStorage.getItem(ACCOUNTS_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  function saveAccounts(accounts) {
    localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
  }

  function getSession() {
    return localStorage.getItem(SESSION_KEY) || "";
  }

  function setSession(username) {
    if (username) localStorage.setItem(SESSION_KEY, username);
    else localStorage.removeItem(SESSION_KEY);
  }

  async function ensureOwnerSeed() {
    const accounts = loadAccounts();
    if (accounts.some((a) => a.username.toLowerCase() === "kyrorg")) return;
    const salt = randomSalt();
    const hash = await sha256Hex(salt + "SUPER SUS");
    accounts.push({
      username: "KyroRG",
      salt,
      hash,
      isOwner: true,
      createdAt: Date.now(),
    });
    saveAccounts(accounts);
  }

  async function registerAccount(username, password) {
    const accounts = loadAccounts();
    if (accounts.some((a) => a.username.toLowerCase() === username.toLowerCase())) {
      return { ok: false, reason: "taken" };
    }
    const salt = randomSalt();
    const hash = await sha256Hex(salt + password);
    accounts.push({ username, salt, hash, isOwner: false, createdAt: Date.now() });
    saveAccounts(accounts);
    return { ok: true };
  }

  async function verifyLogin(username, password) {
    const accounts = loadAccounts();
    const acc = accounts.find((a) => a.username.toLowerCase() === username.toLowerCase());
    if (!acc) return { ok: false, reason: "not-found" };
    const hash = await sha256Hex(acc.salt + password);
    if (hash !== acc.hash) return { ok: false, reason: "wrong-password" };
    return { ok: true, account: acc };
  }

  function currentAccount() {
    const username = getSession();
    if (!username) return null;
    return loadAccounts().find((a) => a.username.toLowerCase() === username.toLowerCase()) || null;
  }

  async function changePassword(currentPassword, newPassword) {
    const acc = currentAccount();
    if (!acc) return { ok: false, reason: "no-session" };

    const currentHash = await sha256Hex(acc.salt + currentPassword);
    if (currentHash !== acc.hash) return { ok: false, reason: "wrong-current" };

    const accounts = loadAccounts();
    const idx = accounts.findIndex((a) => a.username.toLowerCase() === acc.username.toLowerCase());
    if (idx === -1) return { ok: false, reason: "not-found" };

    const newSalt = randomSalt();
    const newHash = await sha256Hex(newSalt + newPassword);
    accounts[idx].salt = newSalt;
    accounts[idx].hash = newHash;
    saveAccounts(accounts);
    return { ok: true };
  }

  // ---------- SCREEN NAVIGATION (animasi smooth: push/pop/crossfade) ----------
  const screenAuth = document.getElementById("screen-auth");
  const screenHome = document.getElementById("screen-home");
  const screenCreate = document.getElementById("screen-create");
  const screenDetail = document.getElementById("screen-detail");
  const screenOwner = document.getElementById("screen-owner");
  const screenPassword = document.getElementById("screen-password");
  const OVERLAY_SCREENS = [screenCreate, screenDetail, screenOwner, screenPassword];
  const ALL_SCREENS = [screenAuth, screenHome, screenCreate, screenDetail, screenOwner, screenPassword];

  function resetScreenState(el) {
    el.classList.remove("is-front", "is-offright", "is-offleft", "is-faded", "is-hidden");
  }

  // Set langsung tanpa animasi (dipakai sekali saat halaman pertama dimuat).
  function setInitialScreen(activeScreen) {
    ALL_SCREENS.forEach((s) => {
      resetScreenState(s);
      if (s === activeScreen) s.classList.add("is-front");
      else s.classList.add("is-hidden");
    });
  }

  // Navigasi MAJU (mis. Home -> Create/Detail/Owner/Password): layar baru
  // slide masuk penuh dari kanan, layar lama slide/fade keluar ke kiri lalu
  // di-hidden total begitu animasinya selesai — TIDAK pernah nyisa
  // setengah-kelihatan/interaktif di belakang.
  function goForward(next, prev) {
    resetScreenState(next);
    next.classList.add("is-offright");
    void next.offsetWidth; // paksa reflow biar posisi awal "dicatat" browser

    requestAnimationFrame(() => {
      next.classList.remove("is-offright");
      next.classList.add("is-front");
    });

    prev.classList.remove("is-front");
    prev.classList.add("is-offleft");

    const onEnd = (e) => {
      if (e.target !== prev || e.propertyName !== "opacity") return;
      prev.classList.remove("is-offleft");
      prev.classList.add("is-hidden");
      prev.removeEventListener("transitionend", onEnd);
    };
    prev.addEventListener("transitionend", onEnd);
  }

  // Navigasi MUNDUR (mis. Create/Detail/Owner/Password -> Home): kebalikan
  // goForward — layar lama slide keluar ke kanan lalu di-hidden total,
  // layar baru slide masuk dari kiri.
  function goBackward(next, prev) {
    resetScreenState(next);
    next.classList.add("is-offleft");
    void next.offsetWidth;

    requestAnimationFrame(() => {
      next.classList.remove("is-offleft");
      next.classList.add("is-front");
    });

    prev.classList.remove("is-front");
    prev.classList.add("is-offright");

    const onEnd = (e) => {
      if (e.target !== prev || e.propertyName !== "transform") return;
      prev.classList.remove("is-offright");
      prev.classList.add("is-hidden");
      prev.removeEventListener("transitionend", onEnd);
    };
    prev.addEventListener("transitionend", onEnd);
  }

  function pushOverlay(overlay) {
    goForward(overlay, screenHome);
  }

  function popOverlay(overlay) {
    goBackward(screenHome, overlay);
  }

  // Auth <-> Home: crossfade halus (bukan slide, karena bukan hubungan
  // "buka overlay" tapi ganti konteks sepenuhnya). Sama seperti di atas,
  // layar lama di-hidden total begitu fade-nya kelar.
  function crossfade(next, prev) {
    resetScreenState(next);
    next.classList.add("is-faded");
    void next.offsetWidth;

    requestAnimationFrame(() => {
      next.classList.remove("is-faded");
      next.classList.add("is-front");
    });

    prev.classList.remove("is-front");
    prev.classList.add("is-faded");

    const onEnd = (e) => {
      if (e.target !== prev || e.propertyName !== "opacity") return;
      prev.classList.remove("is-faded");
      prev.classList.add("is-hidden");
      prev.removeEventListener("transitionend", onEnd);
    };
    prev.addEventListener("transitionend", onEnd);
  }

  // ---------- HOME: RENDER LIST ----------
  const savingsList = document.getElementById("savings-list");
  const emptyState = document.getElementById("empty-state");

  function renderHome() {
    const goals = loadGoals();
    savingsList.innerHTML = "";

    if (goals.length === 0) {
      emptyState.classList.remove("hidden");
      return;
    }
    emptyState.classList.add("hidden");

    goals.forEach((g) => {
      const pct = g.target > 0 ? Math.min(100, Math.round((g.currentTotal / g.target) * 100)) : 0;

      const card = document.createElement("div");
      card.className = "saving-card";
      card.innerHTML = `
        <img class="saving-card-thumb" src="${g.image || ""}" alt="">
        <div class="saving-card-body">
          <div class="saving-card-name">${escapeHtml(g.name)}</div>
          <div class="saving-card-amounts">${formatRupiah(g.currentTotal)} / ${formatRupiah(g.target)}</div>
          <div class="saving-card-track"><div class="saving-card-track-fill" style="width:${pct}%"></div></div>
        </div>
      `;
      card.addEventListener("click", () => openDetail(g.id));
      savingsList.appendChild(card);
    });
  }

  function escapeHtml(str) {
    const d = document.createElement("div");
    d.textContent = str == null ? "" : String(str);
    return d.innerHTML;
  }

  const homeUsername = document.getElementById("home-username");
  const ownerPanelBtn = document.getElementById("owner-panel-btn");
  const logoutBtn = document.getElementById("logout-btn");

  function enterApp(fromAuth) {
    const acc = currentAccount();
    homeUsername.textContent = acc ? acc.username : "Celengan";
    ownerPanelBtn.classList.toggle("hidden", !(acc && acc.isOwner));
    renderHome();
    if (fromAuth) {
      crossfade(screenHome, screenAuth);
    }
  }

  logoutBtn.addEventListener("click", () => {
    setSession("");
    crossfade(screenAuth, screenHome);
  });

  // ---------- GANTI PASSWORD ----------
  const changePasswordBtn = document.getElementById("change-password-btn");
  const passwordAccountLabel = document.getElementById("password-account-label");
  const pwCurrent = document.getElementById("pw-current");
  const pwNew = document.getElementById("pw-new");
  const pwNew2 = document.getElementById("pw-new-2");
  const pwMsg = document.getElementById("pw-msg");
  const pwSubmitBtn = document.getElementById("pw-submit-btn");

  changePasswordBtn.addEventListener("click", () => {
    const acc = currentAccount();
    passwordAccountLabel.textContent = acc ? "Akun: " + acc.username : "-";
    pwCurrent.value = "";
    pwNew.value = "";
    pwNew2.value = "";
    pwMsg.textContent = "";
    pwMsg.className = "field-msg";
    pushOverlay(screenPassword);
  });

  document.getElementById("password-back-btn").addEventListener("click", () => popOverlay(screenPassword));

  pwSubmitBtn.addEventListener("click", async () => {
    const current = pwCurrent.value;
    const next = pwNew.value;
    const next2 = pwNew2.value;

    if (!current) {
      pwMsg.textContent = "Masukkan password saat ini.";
      pwMsg.className = "field-msg error";
      return;
    }
    if (!next || next.length < 4) {
      pwMsg.textContent = "Password baru minimal 4 karakter.";
      pwMsg.className = "field-msg error";
      return;
    }
    if (next !== next2) {
      pwMsg.textContent = "Ulangi password baru tidak cocok.";
      pwMsg.className = "field-msg error";
      return;
    }

    pwMsg.textContent = "Menyimpan...";
    pwMsg.className = "field-msg";

    const result = await changePassword(current, next);
    if (!result.ok) {
      pwMsg.textContent = result.reason === "wrong-current" ? "Password saat ini salah." : "Gagal mengubah password.";
      pwMsg.className = "field-msg error";
      return;
    }

    pwMsg.textContent = "Password berhasil diubah.";
    pwMsg.className = "field-msg success";
    pwCurrent.value = "";
    pwNew.value = "";
    pwNew2.value = "";
  });

  document.getElementById("open-create-btn").addEventListener("click", () => {
    resetCreateForm();
    pushOverlay(screenCreate);
  });

  // ---------- CREATE FORM ----------
  const imageUploadBox = document.getElementById("image-upload-box");
  const imageInput = document.getElementById("image-input");
  const imagePreview = document.getElementById("image-preview");
  const imagePlaceholder = document.getElementById("image-placeholder");
  const inputName = document.getElementById("input-name");
  const inputTarget = document.getElementById("input-target");
  const inputDaily = document.getElementById("input-daily");
  const inputTime = document.getElementById("input-time");
  const dayGrid = document.getElementById("day-grid");
  const createMsg = document.getElementById("create-msg");
  const submitCreateBtn = document.getElementById("submit-create-btn");

  let selectedDays = [];
  let selectedImageData = "";

  attachThousandFormatting(inputTarget);
  attachThousandFormatting(inputDaily);

  function resetCreateForm() {
    inputName.value = "";
    inputTarget.value = "";
    inputDaily.value = "";
    inputTime.value = "";
    selectedDays = [];
    selectedImageData = "";
    imagePreview.src = "";
    imagePreview.classList.add("hidden");
    imagePlaceholder.classList.remove("hidden");
    createMsg.textContent = "";
    createMsg.className = "field-msg";
    dayGrid.querySelectorAll(".day-btn").forEach((b) => b.classList.remove("active"));
  }

  imageUploadBox.addEventListener("click", () => imageInput.click());

  imageInput.addEventListener("change", () => {
    const file = imageInput.files && imageInput.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      selectedImageData = reader.result;
      imagePreview.src = selectedImageData;
      imagePreview.classList.remove("hidden");
      imagePlaceholder.classList.add("hidden");
    };
    reader.readAsDataURL(file);
  });

  dayGrid.querySelectorAll(".day-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const day = btn.dataset.day;
      if (selectedDays.includes(day)) {
        selectedDays = selectedDays.filter((d) => d !== day);
        btn.classList.remove("active");
      } else {
        selectedDays.push(day);
        btn.classList.add("active");
      }
    });
  });

  document.getElementById("create-back-btn").addEventListener("click", () => popOverlay(screenCreate));

  submitCreateBtn.addEventListener("click", () => {
    const name = inputName.value.trim();
    const target = parseFormattedNumber(inputTarget);
    const daily = parseFormattedNumber(inputDaily);

    if (!name) {
      createMsg.textContent = "Nama tabungan wajib diisi.";
      createMsg.className = "field-msg error";
      return;
    }
    if (!target || target <= 0) {
      createMsg.textContent = "Target tabungan harus lebih dari 0.";
      createMsg.className = "field-msg error";
      return;
    }
    if (!daily || daily <= 0) {
      createMsg.textContent = "Menabung perhari harus lebih dari 0.";
      createMsg.className = "field-msg error";
      return;
    }

    const goals = loadGoals();
    const createdAt = Date.now();
    const newGoal = {
      id: uid(),
      name,
      image: selectedImageData,
      target,
      dailyAmount: daily,
      days: selectedDays.slice(),
      time: inputTime.value || "",
      createdAt,
      estimatedCompletion: computeEstimatedCompletion(createdAt, target, daily, selectedDays),
      currentTotal: 0,
      history: [],
    };
    goals.unshift(newGoal);
    saveGoals(goals);

    scheduleReminder(newGoal);

    renderHome();
    popOverlay(screenCreate);
  });

  // ---------- DETAIL SCREEN ----------
  const detailTitle = document.getElementById("detail-title");
  const detailImage = document.getElementById("detail-image");
  const detailCurrent = document.getElementById("detail-current");
  const detailTarget = document.getElementById("detail-target");
  const detailProgressFill = document.getElementById("detail-progress-fill");
  const detailDaily = document.getElementById("detail-daily");
  const detailSchedule = document.getElementById("detail-schedule");
  const detailCreated = document.getElementById("detail-created");
  const detailFinish = document.getElementById("detail-finish");
  const historyBox = document.getElementById("history-box");
  const addAmount = document.getElementById("add-amount");
  const addReason = document.getElementById("add-reason");
  const addMsg = document.getElementById("add-msg");
  const addFundBtn = document.getElementById("add-fund-btn");
  const detailDeleteBtn = document.getElementById("detail-delete-btn");

  let currentGoalId = null;

  attachThousandFormatting(addAmount);

  function openDetail(id) {
    currentGoalId = id;
    renderDetail();
    addAmount.value = "";
    addReason.value = "";
    addMsg.textContent = "";
    addMsg.className = "field-msg";
    pushOverlay(screenDetail);
  }

  function renderDetail() {
    const goals = loadGoals();
    const g = goals.find((x) => x.id === currentGoalId);
    if (!g) {
      popOverlay(screenDetail);
      return;
    }

    detailTitle.textContent = g.name;
    detailImage.src = g.image || "";
    detailCurrent.textContent = formatRupiah(g.currentTotal);
    detailTarget.textContent = "/ " + formatRupiah(g.target);

    const pct = g.target > 0 ? Math.min(100, Math.round((g.currentTotal / g.target) * 100)) : 0;
    detailProgressFill.style.width = pct + "%";

    detailDaily.textContent = "Target harian: " + formatRupiah(g.dailyAmount);
    const daysText = g.days && g.days.length ? g.days.join(", ") : "-";
    const timeText = g.time || "-";
    detailSchedule.textContent = daysText + " • " + timeText;

    detailCreated.textContent = formatDateLong(g.createdAt);
    detailFinish.textContent = g.currentTotal >= g.target
      ? formatDateLong(Date.now()) + " (tercapai)"
      : formatDateLong(g.estimatedCompletion);

    // history, terbaru di atas
    historyBox.innerHTML = "";
    if (!g.history || g.history.length === 0) {
      historyBox.innerHTML = '<span class="placeholder">Belum ada riwayat menabung.</span>';
    } else {
      const sorted = g.history.slice().sort((a, b) => b.timestamp - a.timestamp);
      sorted.forEach((h) => {
        const d = new Date(h.timestamp);
        const tanggal = d.toLocaleDateString("id-ID", { day: "2-digit", month: "2-digit", year: "numeric" });
        const hari = DAY_NAMES[d.getDay()];
        const waktu = d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });

        const entry = document.createElement("div");
        entry.className = "history-entry";
        entry.innerHTML = `
          <div class="history-entry-left">
            <div class="history-entry-reason">${escapeHtml(h.reason || "-")}</div>
            <div class="history-entry-time">${hari}, ${tanggal} • ${waktu}</div>
          </div>
          <div class="history-entry-amount">+${formatRupiah(h.amount)}</div>
        `;
        historyBox.appendChild(entry);
      });
    }
  }

  document.getElementById("detail-back-btn").addEventListener("click", () => {
    renderHome();
    popOverlay(screenDetail);
  });

  addFundBtn.addEventListener("click", () => {
    const amount = parseFormattedNumber(addAmount);
    const reason = addReason.value.trim();

    if (!amount || amount <= 0) {
      addMsg.textContent = "Jumlah uang harus lebih dari 0.";
      addMsg.className = "field-msg error";
      return;
    }

    const goals = loadGoals();
    const g = goals.find((x) => x.id === currentGoalId);
    if (!g) return;

    g.currentTotal = (g.currentTotal || 0) + amount;
    g.history = g.history || [];
    g.history.push({
      id: uid(),
      timestamp: Date.now(),
      amount,
      reason,
    });
    saveGoals(goals);

    addAmount.value = "";
    addReason.value = "";
    addMsg.textContent = "Berhasil ditambahkan.";
    addMsg.className = "field-msg success";

    renderDetail();
  });

  detailDeleteBtn.addEventListener("click", () => {
    if (!confirm("Hapus tabungan ini? Semua history akan hilang.")) return;
    let goals = loadGoals();
    const g = goals.find((x) => x.id === currentGoalId);
    if (g) cancelNativeReminder(g);
    goals = goals.filter((x) => x.id !== currentGoalId);
    saveGoals(goals);
    renderHome();
    popOverlay(screenDetail);
  });

  // ---------- NOTIFIKASI ----------
  // Ubah string jadi angka positif untuk id notifikasi Capacitor (harus int).
  function hashToId(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash * 31 + str.charCodeAt(i)) >>> 0;
    }
    return (hash % 2000000000) + 1;
  }

  function notificationIdsFor(goal) {
    const days = goal.days && goal.days.length ? goal.days : DAY_NAMES.slice();
    return days.map((d) => hashToId(goal.id + "|" + d));
  }

  // APK (Capacitor Local Notifications) — notifikasi ASLI, tetap muncul
  // walau app ditutup, berulang tiap minggu di hari+jam yang dipilih.
  // Butuh plugin @capacitor/local-notifications (lihat README).
  async function scheduleNativeReminder(goal) {
    const cap = window.Capacitor;
    if (!cap || !cap.Plugins || !cap.Plugins.LocalNotifications || !goal.time) return false;
    const LN = cap.Plugins.LocalNotifications;

    try {
      const perm = await LN.requestPermissions();
      if (perm.display !== "granted") return false;
    } catch (e) {
      return false;
    }

    const [hh, mm] = goal.time.split(":").map(Number);
    const days = goal.days && goal.days.length ? goal.days : DAY_NAMES.slice();

    const notifications = days.map((d) => ({
      id: hashToId(goal.id + "|" + d),
      title: "Waktunya Menabung! 🐷",
      body: 'Jangan lupa menabung untuk "' + goal.name + '" hari ini.',
      schedule: {
        on: { weekday: CAP_WEEKDAY[d], hour: hh, minute: mm },
        allowWhileIdle: true,
      },
    }));

    try {
      await LN.schedule({ notifications });
      return true;
    } catch (e) {
      return false;
    }
  }

  async function cancelNativeReminder(goal) {
    const cap = window.Capacitor;
    if (!cap || !cap.Plugins || !cap.Plugins.LocalNotifications) return;
    try {
      const ids = notificationIdsFor(goal).map((id) => ({ id }));
      await cap.Plugins.LocalNotifications.cancel({ notifications: ids });
    } catch (e) {
      // abaikan
    }
  }

  // Browser biasa — pakai Web Notification API. CATATAN JUJUR: ini cuma
  // bisa muncul selama tab/app ini terbuka di background, karena browser
  // tidak bisa membangunkan sendiri seperti alarm sistem. Untuk notifikasi
  // yang jalan walau app ditutup total, itu perlu jalur native di atas
  // (setelah dibungkus APK dengan plugin Local Notifications).
  function requestBrowserPermission() {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission().catch(() => {});
    }
  }

  const notifiedThisMinute = new Set();

  function checkBrowserReminders() {
    if (!("Notification" in window) || Notification.permission !== "granted") return;
    const goals = loadGoals();
    const now = new Date();
    const hh = String(now.getHours()).padStart(2, "0");
    const mm = String(now.getMinutes()).padStart(2, "0");
    const nowTime = hh + ":" + mm;
    const todayName = DAY_NAMES[now.getDay()];
    const minuteKey = now.toDateString() + " " + nowTime;

    goals.forEach((g) => {
      if (!g.time || g.time !== nowTime) return;
      const days = g.days && g.days.length ? g.days : DAY_NAMES.slice();
      if (!days.includes(todayName)) return;

      const key = g.id + "|" + minuteKey;
      if (notifiedThisMinute.has(key)) return;
      notifiedThisMinute.add(key);

      try {
        new Notification("Waktunya Menabung! 🐷", {
          body: 'Jangan lupa menabung untuk "' + g.name + '" hari ini.',
        });
      } catch (e) {
        // beberapa browser mobile tidak izinkan new Notification() langsung
      }
    });
  }

  function scheduleReminder(goal) {
    requestBrowserPermission();
    scheduleNativeReminder(goal); // no-op kalau bukan APK/plugin belum ada
  }

  setInterval(checkBrowserReminders, 15000);
  requestBrowserPermission();

  // ---------- OWNER PANEL (statistik agregat saja, bukan data per-akun) ----------
  const ownerTotalUsers = document.getElementById("owner-total-users");
  const ownerTotalGoals = document.getElementById("owner-total-goals");
  const ownerTotalSaved = document.getElementById("owner-total-saved");
  const ownerAvgSaved = document.getElementById("owner-avg-saved");
  const ownerUserList = document.getElementById("owner-user-list");

  function renderOwnerPanel() {
    const accounts = loadAccounts();
    let totalGoals = 0;
    let totalSaved = 0;

    accounts.forEach((acc) => {
      try {
        const raw = localStorage.getItem(STORAGE_KEY_PREFIX + acc.username);
        const goals = raw ? JSON.parse(raw) : [];
        totalGoals += goals.length;
        goals.forEach((g) => { totalSaved += g.currentTotal || 0; });
      } catch (e) {
        // lewati akun yang datanya rusak/tidak terbaca
      }
    });

    ownerTotalUsers.textContent = String(accounts.length);
    ownerTotalGoals.textContent = String(totalGoals);
    ownerTotalSaved.textContent = formatRupiah(totalSaved);
    ownerAvgSaved.textContent = formatRupiah(accounts.length ? Math.round(totalSaved / accounts.length) : 0);

    // Daftar username saja — TIDAK ada password/hash/data tabungan pribadi.
    ownerUserList.innerHTML = "";
    accounts
      .slice()
      .sort((a, b) => a.createdAt - b.createdAt)
      .forEach((acc) => {
        const row = document.createElement("div");
        row.className = "owner-user-row";
        row.innerHTML = `
          <span>${escapeHtml(acc.username)}</span>
          ${acc.isOwner ? '<span class="owner-user-badge">OWNER</span>' : ""}
        `;
        ownerUserList.appendChild(row);
      });
  }

  ownerPanelBtn.addEventListener("click", () => {
    renderOwnerPanel();
    pushOverlay(screenOwner);
  });

  document.getElementById("owner-back-btn").addEventListener("click", () => {
    popOverlay(screenOwner);
  });

  // ---------- AUTH: TAB SWITCH + LOGIN + DAFTAR ----------
  const tabLogin = document.getElementById("tab-login");
  const tabRegister = document.getElementById("tab-register");
  const formLogin = document.getElementById("auth-form-login");
  const formRegister = document.getElementById("auth-form-register");

  const loginUsername = document.getElementById("login-username");
  const loginPassword = document.getElementById("login-password");
  const loginMsg = document.getElementById("login-msg");
  const loginBtn = document.getElementById("login-btn");

  const registerUsername = document.getElementById("register-username");
  const registerPassword = document.getElementById("register-password");
  const registerPassword2 = document.getElementById("register-password-2");
  const registerMsg = document.getElementById("register-msg");
  const registerBtn = document.getElementById("register-btn");

  // Ganti form Login/Daftar dengan crossfade halus, bukan hidden instan.
  // hideForm fade+geser dulu, BARU showForm muncul setelah itu selesai —
  // supaya tidak ada dua form numpuk (tinggi form beda, cegah "lompat").
  let authSwitching = false;
  function switchAuthForm(showForm, hideForm) {
    if (authSwitching || showForm === hideForm) return;
    if (!hideForm.classList.contains("hidden")) {
      authSwitching = true;
      hideForm.classList.add("auth-form-fading");
      const onEnd = (e) => {
        if (e.target !== hideForm || e.propertyName !== "opacity") return;
        hideForm.removeEventListener("transitionend", onEnd);
        hideForm.classList.add("hidden");
        hideForm.classList.remove("auth-form-fading");

        showForm.classList.remove("hidden");
        showForm.classList.add("auth-form-fading");
        void showForm.offsetWidth;
        requestAnimationFrame(() => {
          showForm.classList.remove("auth-form-fading");
          authSwitching = false;
        });
      };
      hideForm.addEventListener("transitionend", onEnd);
    } else {
      showForm.classList.remove("hidden");
    }
  }

  tabLogin.addEventListener("click", () => {
    tabLogin.classList.add("active");
    tabRegister.classList.remove("active");
    switchAuthForm(formLogin, formRegister);
  });

  tabRegister.addEventListener("click", () => {
    tabRegister.classList.add("active");
    tabLogin.classList.remove("active");
    switchAuthForm(formRegister, formLogin);
  });

  loginBtn.addEventListener("click", async () => {
    const username = loginUsername.value.trim();
    const password = loginPassword.value;

    if (!username || !password) {
      loginMsg.textContent = "Username dan password wajib diisi.";
      loginMsg.className = "field-msg error";
      return;
    }

    loginMsg.textContent = "Memeriksa...";
    loginMsg.className = "field-msg";

    const result = await verifyLogin(username, password);
    if (!result.ok) {
      loginMsg.textContent = result.reason === "not-found" ? "Akun tidak ditemukan." : "Password salah.";
      loginMsg.className = "field-msg error";
      return;
    }

    setSession(result.account.username);
    loginPassword.value = "";
    loginMsg.textContent = "";
    enterApp(true);
  });

  registerBtn.addEventListener("click", async () => {
    const username = registerUsername.value.trim();
    const password = registerPassword.value;
    const password2 = registerPassword2.value;

    if (!username || username.length < 3) {
      registerMsg.textContent = "Username minimal 3 karakter.";
      registerMsg.className = "field-msg error";
      return;
    }
    if (!password || password.length < 4) {
      registerMsg.textContent = "Password minimal 4 karakter.";
      registerMsg.className = "field-msg error";
      return;
    }
    if (password !== password2) {
      registerMsg.textContent = "Ulangi password tidak cocok.";
      registerMsg.className = "field-msg error";
      return;
    }

    registerMsg.textContent = "Mendaftarkan...";
    registerMsg.className = "field-msg";

    const result = await registerAccount(username, password);
    if (!result.ok) {
      registerMsg.textContent = "Username sudah dipakai, coba yang lain.";
      registerMsg.className = "field-msg error";
      return;
    }

    setSession(username);
    registerPassword.value = "";
    registerPassword2.value = "";
    registerMsg.textContent = "";
    enterApp(true);
  });

  // ---------- INIT ----------
  (async function init() {
    await ensureOwnerSeed();
    if (getSession()) {
      setInitialScreen(screenHome);
      enterApp(false);
    } else {
      setInitialScreen(screenAuth);
    }
  })();
})();
